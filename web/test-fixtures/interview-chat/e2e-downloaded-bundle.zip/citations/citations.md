---

## Citations

[1] **Summary** (h2:Summary)
[2] **Experience** (h2:Experience)
[3] **Skills** (h2:Skills)