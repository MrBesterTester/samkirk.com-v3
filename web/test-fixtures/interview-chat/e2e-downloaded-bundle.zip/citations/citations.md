---

## Citations

[1] **Sam Kirk > Summary > Experience > Education > Master of Science in Computer Science** (h1:Sam Kirk > h2:Summary > h2:Experience > h2:Education > h3:Master of Science in Computer Science)
[2] **Sam Kirk > Summary** (h1:Sam Kirk > h2:Summary)
[3] **Sam Kirk > Summary > Experience > Education > Bachelor of Science in Computer Science** (h1:Sam Kirk > h2:Summary > h2:Experience > h2:Education > h3:Bachelor of Science in Computer Science)
[4] **Sam Kirk > Summary > Experience > Education > Skills > Soft Skills** (h1:Sam Kirk > h2:Summary > h2:Experience > h2:Education > h2:Skills > h3:Soft Skills)
[5] **Sam Kirk > Certifications; Sam Kirk > Contact** (h1:Sam Kirk > h2:Certifications; h1:Sam Kirk > h2:Contact)
[6] **Sam Kirk > Summary > Experience > Software Engineer at Startup Inc (2017-2020)** (h1:Sam Kirk > h2:Summary > h2:Experience > h3:Software Engineer at Startup Inc (2017-2020))
[7] **Sam Kirk > Summary > Experience > Junior Developer at Agency Co (2014-2017)** (h1:Sam Kirk > h2:Summary > h2:Experience > h3:Junior Developer at Agency Co (2014-2017))
[8] **Sam Kirk > Summary > Experience > Education > Skills > Technical Skills** (h1:Sam Kirk > h2:Summary > h2:Experience > h2:Education > h2:Skills > h3:Technical Skills)
[9] **Sam Kirk > Summary > Experience > Education > Skills > Projects > Open Source Contributions** (h1:Sam Kirk > h2:Summary > h2:Experience > h2:Education > h2:Skills > h2:Projects > h3:Open Source Contributions)
[10] **Sam Kirk > Summary > Experience > Education > Skills > Projects > Personal Website (samkirk.com)** (h1:Sam Kirk > h2:Summary > h2:Experience > h2:Education > h2:Skills > h2:Projects > h3:Personal Website (samkirk.com))
[11] **Sam Kirk > Summary > Experience > Senior Software Engineer at Tech Company (2020-Present)** (h1:Sam Kirk > h2:Summary > h2:Experience > h3:Senior Software Engineer at Tech Company (2020-Present))